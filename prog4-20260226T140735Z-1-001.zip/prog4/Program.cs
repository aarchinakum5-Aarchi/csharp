﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float p, r, n, i;

            Console.WriteLine("enter principal value:");
            p = float.Parse(Console.ReadLine());
            Console.WriteLine("enter Rate value:");

            r = float.Parse(Console.ReadLine());
            Console.WriteLine("enter years value):");

            Console.Write("enter year:");
            n = float.Parse(Console.ReadLine());

            float d = 1 + r / 100;
            i = p * d;

            
            Console.WriteLine("compound intertes = " + i);


           

        }
    }
}
