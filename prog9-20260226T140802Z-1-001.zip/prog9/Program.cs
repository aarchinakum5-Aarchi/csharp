﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fibonacci_number
{
    internal class Program
    { 
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("enter the value of n");
            n = int.Parse(Console.ReadLine());
            int n1 = 0;
            int n2 = 1;

            Console.WriteLine(n1 + "  ");
            Console.WriteLine(n2 + "  ");

            int n3 = 0;
            while (n3 <= n) 
            {
                n3 = n1 + n2;
                Console.WriteLine(n3 + "  ");
                n1 = n2;
                n2 = n3;
            }
        }
    }
}
