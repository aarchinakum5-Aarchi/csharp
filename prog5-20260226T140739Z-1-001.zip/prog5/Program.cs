﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float pi = 3.14f;

            Console.WriteLine("enter radius of circle:");
           float r = float.Parse(Console.ReadLine());

           float  a = pi * r * r;

            Console.Write("Area of circle = " + a);
        }
    }
}
