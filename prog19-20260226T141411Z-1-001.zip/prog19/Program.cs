﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog19
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] arr = new int[5];
            int min;

            Console.WriteLine("enter 5 number :");
            for (int i = 0; i < 5; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());

            }
            min = arr[0];
            for (int i = 1; i < 5; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];

                }

            }
            Console.WriteLine("minimum number is:" + min);

        }
    }
}