﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number: ");
            num = int.Parse(Console.ReadLine());

            if (num % 2 == 0)
                Console.WriteLine("The number is Even ");

            else
                Console.WriteLine("The number is Odd ");
        }
    }
}
