﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, temp, sum = 0, digit;

            Console.WriteLine("input: ");
            num = int.Parse(Console.ReadLine());

            temp = num;
             while (temp > 0)
            {
                digit = temp % 10;
                sum += digit * digit * digit;
                temp /= 10;

            }
            if (sum == num)
                Console.WriteLine(num + "is an armstorng number");
            else
                Console.WriteLine(num + "is not an armstorng number");

        }
    }
}
