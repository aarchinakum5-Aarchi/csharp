﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prime_number
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            Console.Write("enter a number:");
            int n = int.Parse (Console.ReadLine());
            int m;
            int flag = 0;
            for (int i = 2; i <= n - 1; i++)
            {


                if (n % i == 0)

                    if (m == 0)
                    {
                        Console.WriteLine("not prime no.");
                        flag = 1;
                        break;

                    }
            }
            if (flag == 0) 
            
            {
                Console.WriteLine("Prime no");





            }


          